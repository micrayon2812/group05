<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Iteration 1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>591091cd-b892-4380-b925-a6e3e881a7f5</testSuiteGuid>
   <testCaseLink>
      <guid>af60648d-242a-4115-ae30-13c72d422194</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create a book with lack of required information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>abf90b2c-93d2-445d-b6d2-75813b1b3659</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create a book</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>54795baa-985f-493e-b979-e71a11f6b456</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit user profile with blank information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2f2b87e4-c32f-4f54-8192-eed8066706fb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit user profile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7362b770-7211-4521-8c64-f966d2b0534c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with blank email and password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8fec50be-b77e-4ca4-a4a3-3da2793099ac</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with correct email and password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8ddb2eba-c482-47ba-bc25-a5b34505f85b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with incorrect email</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f8299d31-cb3c-49fc-841a-d30e10416fb2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with incorrect password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4dbe8ee0-9a52-423d-add8-c5b8f0c19116</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up valid procedure</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cd98e65f-ca2b-41dd-8e55-0b4e882d345c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with an existing email</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a31e5c76-4521-4833-af07-53029307e426</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with blank email</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>baeed8b8-4784-4716-aea3-bc6c47eeb0b8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with blank password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>acd31657-388b-44c7-a161-efab53913826</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with wrong format of email</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
