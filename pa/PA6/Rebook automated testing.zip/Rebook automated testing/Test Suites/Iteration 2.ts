<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Iteration 2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>f9570f7d-f0fa-450b-9572-7e385348e95c</testSuiteGuid>
   <testCaseLink>
      <guid>fb86fdb5-3fe8-4af8-925c-0ced1336bcd4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create a book with lack of required information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5dfa25eb-f5f8-44f1-b310-60c8f33da9a0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create a book</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>da55d899-6883-46c2-8e30-a715baca3ce9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit user profile with blank information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ca89bcfd-f795-4101-b69e-86608cedd32d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit user profile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e61ef1e3-4e1f-45e9-ba16-1ffae8f5f486</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with blank email and password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>13556cc3-4e87-4e03-982a-13681fb7bd61</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with correct email and password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3b1b605c-05c0-46aa-9af9-c40bfb071f46</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with incorrect email</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>17b2d10d-327d-4951-99d6-54c45bcecee5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Log in with incorrect password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8d70b557-3c8b-483f-a1ab-92355de3f9d5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up valid procedure</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e8c4fbc7-5015-402d-80fd-a1a219876043</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with an existing email</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7140423e-683e-45ff-be19-3650e8d201b5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with blank email</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d9ce278f-b505-48b2-88e7-476772ce7d2b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with blank password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4310b063-8373-46d9-80ac-0eb7ccdde58b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sign up with wrong format of email</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
