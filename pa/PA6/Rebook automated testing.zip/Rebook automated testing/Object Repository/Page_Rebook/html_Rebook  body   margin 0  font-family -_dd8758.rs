<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>html_Rebook  body   margin 0  font-family -_dd8758</name>
   <tag></tag>
   <elementGuidId>f9aaaafe-3f34-4ba6-83ed-21d850c7ea08</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>html</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='']/parent::*</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>en</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
    
    
    
 
    
    
    
    
    
    

    Re:book
  body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}

.img-grid{
  margin: 20px auto;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-gap: 40px;
}
.img-wrap{
  overflow: hidden;
  height: 0;
  padding: 50% 0;
  /* padding controls height, will always be perfectly square regardless of width */
  position: relative;
  opacity: 0.8;
}
.img-wrap img{
  min-width: 100%;
  min-height: 100%;
  max-width: 150%;
  position: absolute;
  top: 0;
  left: 0;
}
/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvaW5kZXguY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsU0FBUztFQUNUOztjQUVZO0VBQ1osbUNBQW1DO0VBQ25DLGtDQUFrQztBQUNwQzs7QUFFQTtFQUNFO2FBQ1c7QUFDYjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2Isa0NBQWtDO0VBQ2xDLGNBQWM7QUFDaEI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixTQUFTO0VBQ1QsY0FBYztFQUNkLGlGQUFpRjtFQUNqRixrQkFBa0I7RUFDbEIsWUFBWTtBQUNkO0FBQ0E7RUFDRSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsTUFBTTtFQUNOLE9BQU87QUFDVCIsInNvdXJjZXNDb250ZW50IjpbImJvZHkge1xyXG4gIG1hcmdpbjogMDtcclxuICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCAnUm9ib3RvJywgJ094eWdlbicsXHJcbiAgICAnVWJ1bnR1JywgJ0NhbnRhcmVsbCcsICdGaXJhIFNhbnMnLCAnRHJvaWQgU2FucycsICdIZWx2ZXRpY2EgTmV1ZScsXHJcbiAgICBzYW5zLXNlcmlmO1xyXG4gIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xyXG4gIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XHJcbn1cclxuXHJcbmNvZGUge1xyXG4gIGZvbnQtZmFtaWx5OiBzb3VyY2UtY29kZS1wcm8sIE1lbmxvLCBNb25hY28sIENvbnNvbGFzLCAnQ291cmllciBOZXcnLFxyXG4gICAgbW9ub3NwYWNlO1xyXG59XHJcblxyXG4uaW1nLWdyaWR7XHJcbiAgbWFyZ2luOiAyMHB4IGF1dG87XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyO1xyXG4gIGdyaWQtZ2FwOiA0MHB4O1xyXG59XHJcbi5pbWctd3JhcHtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIGhlaWdodDogMDtcclxuICBwYWRkaW5nOiA1MCUgMDtcclxuICAvKiBwYWRkaW5nIGNvbnRyb2xzIGhlaWdodCwgd2lsbCBhbHdheXMgYmUgcGVyZmVjdGx5IHNxdWFyZSByZWdhcmRsZXNzIG9mIHdpZHRoICovXHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG9wYWNpdHk6IDAuODtcclxufVxyXG4uaW1nLXdyYXAgaW1ne1xyXG4gIG1pbi13aWR0aDogMTAwJTtcclxuICBtaW4taGVpZ2h0OiAxMDAlO1xyXG4gIG1heC13aWR0aDogMTUwJTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */.App {
  text-align: center;
}

.App-logo {
  height: 40vmin;
  pointer-events: none;
}

@media (prefers-reduced-motion: no-preference) {
  .App-logo {
    animation: App-logo-spin infinite 20s linear;
  }
}

.App-header {
  background-color: #282c34;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-size: calc(10px + 2vmin);
  color: white;
}

.App-link {
  color: #61dafb;
}

@keyframes App-logo-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}


body {
  color: #000;
  overflow-x: hidden;
  height: 100%;
  background-color: #B0BEC5;
  background-repeat: no-repeat
}

.card0 {
  box-shadow: 0px 4px 8px 0px #757575;
  border-radius: 0px
}

.card2 {
  margin: 0px 40px
}

.logo {
  width: 200px;
  height: 100px;
  margin-top: 20px;
  margin-left: 35px
}

.image {
  width: 360px;
  height: 280px
}

.border-line {
  border-right: 1px solid #EEEEEE
}

.facebook {
  background-color: #3b5998;
  color: #fff;
  font-size: 18px;
  padding-top: 5px;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  cursor: pointer
}

.twitter {
  background-color: #1DA1F2;
  color: #fff;
  font-size: 18px;
  padding-top: 5px;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  cursor: pointer
}

.linkedin {
  background-color: #2867B2;
  color: #fff;
  font-size: 18px;
  padding-top: 5px;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  cursor: pointer
}

.line {
  height: 1px;
  width: 45%;
  background-color: #E0E0E0;
  margin-top: 10px
}

.or {
  width: 10%;
  font-weight: bold
}

.text-sm {
  font-size: 14px !important
}

::placeholder {
  color: #BDBDBD;
  opacity: 1;
  font-weight: 300
}

:-ms-input-placeholder {
  color: #BDBDBD;
  font-weight: 300
}

::-ms-input-placeholder {
  color: #BDBDBD;
  font-weight: 300
}

input,
textarea {
  padding: 10px 12px 10px 12px;
  border: 1px solid lightgrey;
  border-radius: 2px;
  margin-bottom: 5px;
  margin-top: 2px;
  width: 100%;
  box-sizing: border-box;
  color: #2C3E50;
  font-size: 14px;
  letter-spacing: 1px
}

input:focus,
textarea:focus {
  box-shadow: none !important;
  border: 1px solid #304FFE;
  outline-width: 0
}

button:focus {
  box-shadow: none !important;
  outline-width: 0
}

a {
  color: inherit;
  cursor: pointer
}

.btn-blue {
  background-color: #1A237E;
  width: 150px;
  color: #fff;
  border-radius: 2px
}

.btn-blue:hover {
  background-color: #000;
  cursor: pointer
}

.bg-blue {
  color: #fff;
  background-color: #1A237E
}

@media screen and (max-width: 991px) {
  .logo {
      margin-left: 0px
  }

  .image {
      width: 300px;
      height: 220px
  }

  .border-line {
      border-right: none
  }

  .card2 {
      border-top: 1px solid #EEEEEE !important;
      margin: 0px 15px
  }
}

.get-in-touch {
  max-width: 800px;
  margin: 50px auto;
  position: relative;

}
.get-in-touch .title {
  text-align: center;
  text-transform: uppercase;
  letter-spacing: 3px;
  font-size: 3.2em;
  line-height: 48px;
  padding-bottom: 48px;
     color: #5543ca;
    background: #5543ca;
    background: linear-gradient(to right,#f4524d  0%,#5543ca  100%) !important;
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important;
}

.contact-form .form-field {
  position: relative;
  margin: 32px 0;
}
.contact-form .input-text {
  display: block;
  width: 100%;
  height: 0px;
  border-width: 0 0 2px 0;
  border-color: #5543ca;
  font-size: 18px;
  line-height: 26px;
  font-weight: 400;
}
.contact-form .input-text:focus {
  outline: none;
}
.contact-form .input-text:focus + .label,
.contact-form .input-text.not-empty + .label {
  transform: translateY(-24px);
}
.contact-form .label {
  position: absolute;
  left: 20px;
  bottom: 11px;
  font-size: 18px;
  line-height: 50px;
  font-weight: 400;
  color: #5543ca;
  cursor: text;
  transition: transform .2s ease-in-out;
}
.contact-form .submit-btn {
  display: inline-block;
  background-color: #000;
   background-image: linear-gradient(125deg,#a72879,#064497);
  color: #fff;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-size: 16px;
  padding: 8px 16px;
  border: none;
  width:200px;
  cursor: pointer;
}
.contact-form .labelcover {
  position: absolute;
  left: 20px;
  bottom: 11px;
  font-size: 18px;
  line-height: 100px;
  font-weight: 400;
  color: #5543ca;
  cursor: text;
  transition: transform .2s ease-in-out;
}

.btn-outline-home {
  color: #007bff;
  background-color: white;
  background-image: none;
  border-color: #007bff;
}
.btn-outline-home:hover {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}

.btn-outline-home.focus,
.btn-outline-home:focus {
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
}
.btn-outline-home.disabled,
.btn-outline-home:disabled {
  color: #007bff;
  background-color: transparent;
}
.btn-outline-home:not(:disabled):not(.disabled).active,
.btn-outline-home:not(:disabled):not(.disabled):active,
.show > .btn-outline-home.dropdown-toggle {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
.btn-outline-home:not(:disabled):not(.disabled).active:focus,
.btn-outline-home:not(:disabled):not(.disabled):active:focus,
.show > .btn-outline-home.dropdown-toggle:focus {
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
}
.container-fluid1 {
  width: 100%;
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;

}

/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvQXBwLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRTtJQUNFLDRDQUE0QztFQUM5QztBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsNkJBQTZCO0VBQzdCLFlBQVk7QUFDZDs7QUFFQTtFQUNFLGNBQWM7QUFDaEI7O0FBRUE7RUFDRTtJQUNFLHVCQUF1QjtFQUN6QjtFQUNBO0lBQ0UseUJBQXlCO0VBQzNCO0FBQ0Y7OztBQUdBO0VBQ0UsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1oseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRSxtQ0FBbUM7RUFDbkM7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxZQUFZO0VBQ1osYUFBYTtFQUNiLGdCQUFnQjtFQUNoQjtBQUNGOztBQUVBO0VBQ0UsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsV0FBVztFQUNYLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxZQUFZO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixXQUFXO0VBQ1gsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFlBQVk7RUFDWjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLFVBQVU7RUFDVix5QkFBeUI7RUFDekI7QUFDRjs7QUFFQTtFQUNFLFVBQVU7RUFDVjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxVQUFVO0VBQ1Y7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkO0FBQ0Y7O0FBRUE7O0VBRUUsNEJBQTRCO0VBQzVCLDJCQUEyQjtFQUMzQixrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixXQUFXO0VBQ1gsc0JBQXNCO0VBQ3RCLGNBQWM7RUFDZCxlQUFlO0VBQ2Y7QUFDRjs7QUFFQTs7RUFJRSwyQkFBMkI7RUFDM0IseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFHRSwyQkFBMkI7RUFDM0I7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLFlBQVk7RUFDWixXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLHNCQUFzQjtFQUN0QjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtNQUNJO0VBQ0o7O0VBRUE7TUFDSSxZQUFZO01BQ1o7RUFDSjs7RUFFQTtNQUNJO0VBQ0o7O0VBRUE7TUFDSSx3Q0FBd0M7TUFDeEM7RUFDSjtBQUNGOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixrQkFBa0I7O0FBRXBCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLG9CQUFvQjtLQUNqQixjQUFjO0lBQ2YsbUJBQW1CO0lBR25CLDBFQUEwRTtJQUMxRSx3Q0FBd0M7SUFDeEMsK0NBQStDO0FBQ25EOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLGNBQWM7QUFDaEI7QUFDQTtFQUNFLGNBQWM7RUFDZCxXQUFXO0VBQ1gsV0FBVztFQUNYLHVCQUF1QjtFQUN2QixxQkFBcUI7RUFDckIsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLGFBQWE7QUFDZjtBQUNBOztFQUdVLDRCQUE0QjtBQUN0QztBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixZQUFZO0VBQ1osZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLFlBQVk7RUFFWixxQ0FBcUM7QUFHdkM7QUFDQTtFQUNFLHFCQUFxQjtFQUNyQixzQkFBc0I7R0FDckIseURBQXlEO0VBQzFELFdBQVc7RUFDWCx5QkFBeUI7RUFDekIsbUJBQW1CO0VBQ25CLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsWUFBWTtFQUNaLFdBQVc7RUFDWCxlQUFlO0FBQ2pCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsVUFBVTtFQUNWLFlBQVk7RUFDWixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsWUFBWTtFQUVaLHFDQUFxQztBQUd2Qzs7QUFFQTtFQUNFLGNBQWM7RUFDZCx1QkFBdUI7RUFDdkIsc0JBQXNCO0VBQ3RCLHFCQUFxQjtBQUN2QjtBQUNBO0VBQ0UsV0FBVztFQUNYLHlCQUF5QjtFQUN6QixxQkFBcUI7QUFDdkI7O0FBRUE7O0VBRUUsK0NBQStDO0FBQ2pEO0FBQ0E7O0VBRUUsY0FBYztFQUNkLDZCQUE2QjtBQUMvQjtBQUNBOzs7RUFHRSxXQUFXO0VBQ1gseUJBQXlCO0VBQ3pCLHFCQUFxQjtBQUN2QjtBQUNBOzs7RUFHRSwrQ0FBK0M7QUFDakQ7QUFDQTtFQUNFLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixpQkFBaUI7O0FBRW5CIiwic291cmNlc0NvbnRlbnQiOlsiLkFwcCB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uQXBwLWxvZ28ge1xyXG4gIGhlaWdodDogNDB2bWluO1xyXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG59XHJcblxyXG5AbWVkaWEgKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IG5vLXByZWZlcmVuY2UpIHtcclxuICAuQXBwLWxvZ28ge1xyXG4gICAgYW5pbWF0aW9uOiBBcHAtbG9nby1zcGluIGluZmluaXRlIDIwcyBsaW5lYXI7XHJcbiAgfVxyXG59XHJcblxyXG4uQXBwLWhlYWRlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI4MmMzNDtcclxuICBtaW4taGVpZ2h0OiAxMDB2aDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmb250LXNpemU6IGNhbGMoMTBweCArIDJ2bWluKTtcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5BcHAtbGluayB7XHJcbiAgY29sb3I6ICM2MWRhZmI7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgQXBwLWxvZ28tc3BpbiB7XHJcbiAgZnJvbSB7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcclxuICB9XHJcbiAgdG8ge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcclxuICB9XHJcbn1cclxuXHJcblxyXG5ib2R5IHtcclxuICBjb2xvcjogIzAwMDtcclxuICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNCMEJFQzU7XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdFxyXG59XHJcblxyXG4uY2FyZDAge1xyXG4gIGJveC1zaGFkb3c6IDBweCA0cHggOHB4IDBweCAjNzU3NTc1O1xyXG4gIGJvcmRlci1yYWRpdXM6IDBweFxyXG59XHJcblxyXG4uY2FyZDIge1xyXG4gIG1hcmdpbjogMHB4IDQwcHhcclxufVxyXG5cclxuLmxvZ28ge1xyXG4gIHdpZHRoOiAyMDBweDtcclxuICBoZWlnaHQ6IDEwMHB4O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDM1cHhcclxufVxyXG5cclxuLmltYWdlIHtcclxuICB3aWR0aDogMzYwcHg7XHJcbiAgaGVpZ2h0OiAyODBweFxyXG59XHJcblxyXG4uYm9yZGVyLWxpbmUge1xyXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNFRUVFRUVcclxufVxyXG5cclxuLmZhY2Vib29rIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2I1OTk4O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICB3aWR0aDogMzVweDtcclxuICBoZWlnaHQ6IDM1cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyXHJcbn1cclxuXHJcbi50d2l0dGVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMURBMUYyO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICB3aWR0aDogMzVweDtcclxuICBoZWlnaHQ6IDM1cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyXHJcbn1cclxuXHJcbi5saW5rZWRpbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI4NjdCMjtcclxuICBjb2xvcjogI2ZmZjtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgcGFkZGluZy10b3A6IDVweDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgd2lkdGg6IDM1cHg7XHJcbiAgaGVpZ2h0OiAzNXB4O1xyXG4gIGN1cnNvcjogcG9pbnRlclxyXG59XHJcblxyXG4ubGluZSB7XHJcbiAgaGVpZ2h0OiAxcHg7XHJcbiAgd2lkdGg6IDQ1JTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTBFMEUwO1xyXG4gIG1hcmdpbi10b3A6IDEwcHhcclxufVxyXG5cclxuLm9yIHtcclxuICB3aWR0aDogMTAlO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkXHJcbn1cclxuXHJcbi50ZXh0LXNtIHtcclxuICBmb250LXNpemU6IDE0cHggIWltcG9ydGFudFxyXG59XHJcblxyXG46OnBsYWNlaG9sZGVyIHtcclxuICBjb2xvcjogI0JEQkRCRDtcclxuICBvcGFjaXR5OiAxO1xyXG4gIGZvbnQtd2VpZ2h0OiAzMDBcclxufVxyXG5cclxuOi1tcy1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6ICNCREJEQkQ7XHJcbiAgZm9udC13ZWlnaHQ6IDMwMFxyXG59XHJcblxyXG46Oi1tcy1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgY29sb3I6ICNCREJEQkQ7XHJcbiAgZm9udC13ZWlnaHQ6IDMwMFxyXG59XHJcblxyXG5pbnB1dCxcclxudGV4dGFyZWEge1xyXG4gIHBhZGRpbmc6IDEwcHggMTJweCAxMHB4IDEycHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmV5O1xyXG4gIGJvcmRlci1yYWRpdXM6IDJweDtcclxuICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgbWFyZ2luLXRvcDogMnB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgY29sb3I6ICMyQzNFNTA7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGxldHRlci1zcGFjaW5nOiAxcHhcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMsXHJcbnRleHRhcmVhOmZvY3VzIHtcclxuICAtbW96LWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgIzMwNEZGRTtcclxuICBvdXRsaW5lLXdpZHRoOiAwXHJcbn1cclxuXHJcbmJ1dHRvbjpmb2N1cyB7XHJcbiAgLW1vei1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gIG91dGxpbmUtd2lkdGg6IDBcclxufVxyXG5cclxuYSB7XHJcbiAgY29sb3I6IGluaGVyaXQ7XHJcbiAgY3Vyc29yOiBwb2ludGVyXHJcbn1cclxuXHJcbi5idG4tYmx1ZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFBMjM3RTtcclxuICB3aWR0aDogMTUwcHg7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMnB4XHJcbn1cclxuXHJcbi5idG4tYmx1ZTpob3ZlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDtcclxuICBjdXJzb3I6IHBvaW50ZXJcclxufVxyXG5cclxuLmJnLWJsdWUge1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMxQTIzN0VcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogOTkxcHgpIHtcclxuICAubG9nbyB7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAwcHhcclxuICB9XHJcblxyXG4gIC5pbWFnZSB7XHJcbiAgICAgIHdpZHRoOiAzMDBweDtcclxuICAgICAgaGVpZ2h0OiAyMjBweFxyXG4gIH1cclxuXHJcbiAgLmJvcmRlci1saW5lIHtcclxuICAgICAgYm9yZGVyLXJpZ2h0OiBub25lXHJcbiAgfVxyXG5cclxuICAuY2FyZDIge1xyXG4gICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI0VFRUVFRSAhaW1wb3J0YW50O1xyXG4gICAgICBtYXJnaW46IDBweCAxNXB4XHJcbiAgfVxyXG59XHJcblxyXG4uZ2V0LWluLXRvdWNoIHtcclxuICBtYXgtd2lkdGg6IDgwMHB4O1xyXG4gIG1hcmdpbjogNTBweCBhdXRvO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbn1cclxuLmdldC1pbi10b3VjaCAudGl0bGUge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIGxldHRlci1zcGFjaW5nOiAzcHg7XHJcbiAgZm9udC1zaXplOiAzLjJlbTtcclxuICBsaW5lLWhlaWdodDogNDhweDtcclxuICBwYWRkaW5nLWJvdHRvbTogNDhweDtcclxuICAgICBjb2xvcjogIzU1NDNjYTtcclxuICAgIGJhY2tncm91bmQ6ICM1NTQzY2E7XHJcbiAgICBiYWNrZ3JvdW5kOiAtbW96LWxpbmVhci1ncmFkaWVudChsZWZ0LCNmNDUyNGQgIDAlLCM1NTQzY2EgMTAwJSkgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KGxlZnQsI2Y0NTI0ZCAgMCUsIzU1NDNjYSAxMDAlKSAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCNmNDUyNGQgIDAlLCM1NTQzY2EgIDEwMCUpICFpbXBvcnRhbnQ7XHJcbiAgICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dCAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5jb250YWN0LWZvcm0gLmZvcm0tZmllbGQge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBtYXJnaW46IDMycHggMDtcclxufVxyXG4uY29udGFjdC1mb3JtIC5pbnB1dC10ZXh0IHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDBweDtcclxuICBib3JkZXItd2lkdGg6IDAgMCAycHggMDtcclxuICBib3JkZXItY29sb3I6ICM1NTQzY2E7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbn1cclxuLmNvbnRhY3QtZm9ybSAuaW5wdXQtdGV4dDpmb2N1cyB7XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG4uY29udGFjdC1mb3JtIC5pbnB1dC10ZXh0OmZvY3VzICsgLmxhYmVsLFxyXG4uY29udGFjdC1mb3JtIC5pbnB1dC10ZXh0Lm5vdC1lbXB0eSArIC5sYWJlbCB7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTI0cHgpO1xyXG4gICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0yNHB4KTtcclxufVxyXG4uY29udGFjdC1mb3JtIC5sYWJlbCB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGxlZnQ6IDIwcHg7XHJcbiAgYm90dG9tOiAxMXB4O1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBsaW5lLWhlaWdodDogNTBweDtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIGNvbG9yOiAjNTU0M2NhO1xyXG4gIGN1cnNvcjogdGV4dDtcclxuICB0cmFuc2l0aW9uOiAtd2Via2l0LXRyYW5zZm9ybSAuMnMgZWFzZS1pbi1vdXQ7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIC4ycyBlYXNlLWluLW91dDtcclxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gLjJzIGVhc2UtaW4tb3V0LCBcclxuICAtd2Via2l0LXRyYW5zZm9ybSAuMnMgZWFzZS1pbi1vdXQ7XHJcbn1cclxuLmNvbnRhY3QtZm9ybSAuc3VibWl0LWJ0biB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDA7XHJcbiAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgxMjVkZWcsI2E3Mjg3OSwjMDY0NDk3KTtcclxuICBjb2xvcjogI2ZmZjtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIGxldHRlci1zcGFjaW5nOiAycHg7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIHBhZGRpbmc6IDhweCAxNnB4O1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICB3aWR0aDoyMDBweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmNvbnRhY3QtZm9ybSAubGFiZWxjb3ZlciB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGxlZnQ6IDIwcHg7XHJcbiAgYm90dG9tOiAxMXB4O1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBsaW5lLWhlaWdodDogMTAwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBjb2xvcjogIzU1NDNjYTtcclxuICBjdXJzb3I6IHRleHQ7XHJcbiAgdHJhbnNpdGlvbjogLXdlYmtpdC10cmFuc2Zvcm0gLjJzIGVhc2UtaW4tb3V0O1xyXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAuMnMgZWFzZS1pbi1vdXQ7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIC4ycyBlYXNlLWluLW91dCwgXHJcbiAgLXdlYmtpdC10cmFuc2Zvcm0gLjJzIGVhc2UtaW4tb3V0O1xyXG59XHJcblxyXG4uYnRuLW91dGxpbmUtaG9tZSB7XHJcbiAgY29sb3I6ICMwMDdiZmY7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcclxuICBib3JkZXItY29sb3I6ICMwMDdiZmY7XHJcbn1cclxuLmJ0bi1vdXRsaW5lLWhvbWU6aG92ZXIge1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDdiZmY7XHJcbiAgYm9yZGVyLWNvbG9yOiAjMDA3YmZmO1xyXG59XHJcblxyXG4uYnRuLW91dGxpbmUtaG9tZS5mb2N1cyxcclxuLmJ0bi1vdXRsaW5lLWhvbWU6Zm9jdXMge1xyXG4gIGJveC1zaGFkb3c6IDAgMCAwIDAuMnJlbSByZ2JhKDAsIDEyMywgMjU1LCAwLjUpO1xyXG59XHJcbi5idG4tb3V0bGluZS1ob21lLmRpc2FibGVkLFxyXG4uYnRuLW91dGxpbmUtaG9tZTpkaXNhYmxlZCB7XHJcbiAgY29sb3I6ICMwMDdiZmY7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbn1cclxuLmJ0bi1vdXRsaW5lLWhvbWU6bm90KDpkaXNhYmxlZCk6bm90KC5kaXNhYmxlZCkuYWN0aXZlLFxyXG4uYnRuLW91dGxpbmUtaG9tZTpub3QoOmRpc2FibGVkKTpub3QoLmRpc2FibGVkKTphY3RpdmUsXHJcbi5zaG93ID4gLmJ0bi1vdXRsaW5lLWhvbWUuZHJvcGRvd24tdG9nZ2xlIHtcclxuICBjb2xvcjogI2ZmZjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDA3YmZmO1xyXG4gIGJvcmRlci1jb2xvcjogIzAwN2JmZjtcclxufVxyXG4uYnRuLW91dGxpbmUtaG9tZTpub3QoOmRpc2FibGVkKTpub3QoLmRpc2FibGVkKS5hY3RpdmU6Zm9jdXMsXHJcbi5idG4tb3V0bGluZS1ob21lOm5vdCg6ZGlzYWJsZWQpOm5vdCguZGlzYWJsZWQpOmFjdGl2ZTpmb2N1cyxcclxuLnNob3cgPiAuYnRuLW91dGxpbmUtaG9tZS5kcm9wZG93bi10b2dnbGU6Zm9jdXMge1xyXG4gIGJveC1zaGFkb3c6IDAgMCAwIDAuMnJlbSByZ2JhKDAsIDEyMywgMjU1LCAwLjUpO1xyXG59XHJcbi5jb250YWluZXItZmx1aWQxIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nLXJpZ2h0OiAxNXB4O1xyXG4gIHBhZGRpbmctbGVmdDogMTVweDtcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcblxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */.fade {
    opacity: 1;
  }

.bor-blue{
  border-bottom-left-radius: 10%;
  border-style: groove;
  border: blue;
}
/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvUGFnZS5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxVQUFVO0VBQ1o7O0FBRUY7RUFDRSw4QkFBOEI7RUFDOUIsb0JBQW9CO0VBQ3BCLFlBQVk7QUFDZCIsInNvdXJjZXNDb250ZW50IjpbIi5mYWRlIHtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgfVxyXG5cclxuLmJvci1ibHVle1xyXG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDEwJTtcclxuICBib3JkZXItc3R5bGU6IGdyb292ZTtcclxuICBib3JkZXI6IGJsdWU7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */body{
    background-color: rgb(255, 255, 255)

}

.row{
    display:flex;
    flex-direction: row;
    align-items: center;
}
.bg-white {
  
    background-color: rgb(255, 255, 255);
    border-style:double;
    border-top: rgb(130, 0, 113);


  }
.navbar-brand {
    padding: 0.5%;
    font-size: 30px;

    margin: 0;
    padding-left: 20px;
}

.navbar-nav {
    display: flex;
    flex-direction: row;
    width: 88%;
}

.nav-item {
    padding: 20px 8px;
    margin: 0px 30px;
    text-align: center;
    border-radius: 5px;
    font-size: 18px;
    color: rgb(255, 255, 255);
    position: static;
    font-weight: bold;
    
}

.nav-item.active {
    color: #EF5350
}

.nav-item:hover {
    color: #ff009d
}

a {
    color: inherit !important
}

.nav-link {
    padding: 5%;
}

.navbar-collapse.collapse.in {
    display: block !important
}

.fa-angle-down {
    padding-left: 10px
}

.fa-icon {
    font-size: 30px;
    color: rgb(255, 255, 255);
    background-color: rgb(26, 15, 119);
    margin: 2px 10px 5px 0px;
    border-radius: 10px;
    width: 50px;
    height: 50px
}

.dropdown-menu {
    margin-top: 0px;
    border: none;
    background-color: #244cb9b6;
    padding: 50px 50px 30px 50px;
    opacity: 80%;
    color: rgb(255, 255, 255);
}

#dropdown-menu1 {
    position: absolute;
    left: 150px;
}
#dropdown-menu4 {
    position: absolute;
    left: 450px;
}

/* #dropdown-menu2 {
    position: absolute;
    left:  100px
} */

#dropdown-menu3 {
    position: absolute;
    left: 290px
}

.tab {
    margin-bottom: 20px;
    width: 230px
}

.tab:hover {
    color: #E91E63 !important
}

.dropdown-item {
    padding: 0px
}

.dropdown-item:hover {
    background-color: inherit
}

@media (max-width: 767px) {
    .nav-item {
        width: 100%;
        text-align: left;
        padding-left: 10px
    }

    .dropdown-menu {
        left: 0 !important;
        position: relative !important;
        padding: 20px
    }
}

/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvTmF2YmFyLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJOztBQUVKOztBQUVBO0lBQ0ksWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixtQkFBbUI7QUFDdkI7QUFDQTs7SUFFSSxvQ0FBb0M7SUFDcEMsbUJBQW1CO0lBQ25CLDRCQUE0Qjs7O0VBRzlCO0FBQ0Y7SUFDSSxhQUFhO0lBQ2IsZUFBZTs7SUFFZixTQUFTO0lBQ1Qsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksYUFBYTtJQUNiLG1CQUFtQjtJQUNuQixVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLHlCQUF5QjtJQUN6QixnQkFBZ0I7SUFDaEIsaUJBQWlCOztBQUVyQjs7QUFFQTtJQUNJO0FBQ0o7O0FBRUE7SUFDSTtBQUNKOztBQUVBO0lBQ0k7QUFDSjs7QUFFQTtJQUNJLFdBQVc7QUFDZjs7QUFFQTtJQUNJO0FBQ0o7O0FBRUE7SUFDSTtBQUNKOztBQUVBO0lBQ0ksZUFBZTtJQUNmLHlCQUF5QjtJQUN6QixrQ0FBa0M7SUFDbEMsd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1g7QUFDSjs7QUFFQTtJQUNJLGVBQWU7SUFDZixZQUFZO0lBQ1osMkJBQTJCO0lBQzNCLDRCQUE0QjtJQUM1QixZQUFZO0lBQ1oseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFdBQVc7QUFDZjtBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLFdBQVc7QUFDZjs7QUFFQTs7O0dBR0c7O0FBRUg7SUFDSSxrQkFBa0I7SUFDbEI7QUFDSjs7QUFFQTtJQUNJLG1CQUFtQjtJQUNuQjtBQUNKOztBQUVBO0lBQ0k7QUFDSjs7QUFFQTtJQUNJO0FBQ0o7O0FBRUE7SUFDSTtBQUNKOztBQUVBO0lBQ0k7UUFDSSxXQUFXO1FBQ1gsZ0JBQWdCO1FBQ2hCO0lBQ0o7O0lBRUE7UUFDSSxrQkFBa0I7UUFDbEIsNkJBQTZCO1FBQzdCO0lBQ0o7QUFDSiIsInNvdXJjZXNDb250ZW50IjpbImJvZHl7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSlcclxuXHJcbn1cclxuXHJcbi5yb3d7XHJcbiAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uYmctd2hpdGUge1xyXG4gIFxyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgYm9yZGVyLXN0eWxlOmRvdWJsZTtcclxuICAgIGJvcmRlci10b3A6IHJnYigxMzAsIDAsIDExMyk7XHJcblxyXG5cclxuICB9XHJcbi5uYXZiYXItYnJhbmQge1xyXG4gICAgcGFkZGluZzogMC41JTtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuXHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbn1cclxuXHJcbi5uYXZiYXItbmF2IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgd2lkdGg6IDg4JTtcclxufVxyXG5cclxuLm5hdi1pdGVtIHtcclxuICAgIHBhZGRpbmc6IDIwcHggOHB4O1xyXG4gICAgbWFyZ2luOiAwcHggMzBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XHJcbiAgICBwb3NpdGlvbjogc3RhdGljO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBcclxufVxyXG5cclxuLm5hdi1pdGVtLmFjdGl2ZSB7XHJcbiAgICBjb2xvcjogI0VGNTM1MFxyXG59XHJcblxyXG4ubmF2LWl0ZW06aG92ZXIge1xyXG4gICAgY29sb3I6ICNmZjAwOWRcclxufVxyXG5cclxuYSB7XHJcbiAgICBjb2xvcjogaW5oZXJpdCAhaW1wb3J0YW50XHJcbn1cclxuXHJcbi5uYXYtbGluayB7XHJcbiAgICBwYWRkaW5nOiA1JTtcclxufVxyXG5cclxuLm5hdmJhci1jb2xsYXBzZS5jb2xsYXBzZS5pbiB7XHJcbiAgICBkaXNwbGF5OiBibG9jayAhaW1wb3J0YW50XHJcbn1cclxuXHJcbi5mYS1hbmdsZS1kb3duIHtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweFxyXG59XHJcblxyXG4uZmEtaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBjb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI2LCAxNSwgMTE5KTtcclxuICAgIG1hcmdpbjogMnB4IDEwcHggNXB4IDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDogNTBweFxyXG59XHJcblxyXG4uZHJvcGRvd24tbWVudSB7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjQ0Y2I5YjY7XHJcbiAgICBwYWRkaW5nOiA1MHB4IDUwcHggMzBweCA1MHB4O1xyXG4gICAgb3BhY2l0eTogODAlO1xyXG4gICAgY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxufVxyXG5cclxuI2Ryb3Bkb3duLW1lbnUxIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDE1MHB4O1xyXG59XHJcbiNkcm9wZG93bi1tZW51NCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiA0NTBweDtcclxufVxyXG5cclxuLyogI2Ryb3Bkb3duLW1lbnUyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6ICAxMDBweFxyXG59ICovXHJcblxyXG4jZHJvcGRvd24tbWVudTMge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogMjkwcHhcclxufVxyXG5cclxuLnRhYiB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgd2lkdGg6IDIzMHB4XHJcbn1cclxuXHJcbi50YWI6aG92ZXIge1xyXG4gICAgY29sb3I6ICNFOTFFNjMgIWltcG9ydGFudFxyXG59XHJcblxyXG4uZHJvcGRvd24taXRlbSB7XHJcbiAgICBwYWRkaW5nOiAwcHhcclxufVxyXG5cclxuLmRyb3Bkb3duLWl0ZW06aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogaW5oZXJpdFxyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcclxuICAgIC5uYXYtaXRlbSB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHhcclxuICAgIH1cclxuXHJcbiAgICAuZHJvcGRvd24tbWVudSB7XHJcbiAgICAgICAgbGVmdDogMCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIHBhZGRpbmc6IDIwcHhcclxuICAgIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */.img-grid{
    margin: 20px auto;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
    grid-gap: 40px;
  }
  .img-wrap{
    overflow: hidden;
    height: 0;
    padding: 75% 0;
    /* padding controls height, will always be perfectly square regardless of width */
    position: relative;
    opacity: 0.8;
  }
  .img-wrap img{
    min-width: 100%;
    min-height: 100%;
    max-width: 150%;
    position: absolute;
    top: 0;
    left: 0;
  }
/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvQ2F0ZWdvcnkuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUJBQWlCO0lBQ2pCLGFBQWE7SUFDYixzQ0FBc0M7SUFDdEMsY0FBYztFQUNoQjtFQUNBO0lBQ0UsZ0JBQWdCO0lBQ2hCLFNBQVM7SUFDVCxjQUFjO0lBQ2QsaUZBQWlGO0lBQ2pGLGtCQUFrQjtJQUNsQixZQUFZO0VBQ2Q7RUFDQTtJQUNFLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLGtCQUFrQjtJQUNsQixNQUFNO0lBQ04sT0FBTztFQUNUIiwic291cmNlc0NvbnRlbnQiOlsiLmltZy1ncmlke1xyXG4gICAgbWFyZ2luOiAyMHB4IGF1dG87XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyIDFmciAxZnI7XHJcbiAgICBncmlkLWdhcDogNDBweDtcclxuICB9XHJcbiAgLmltZy13cmFwe1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGhlaWdodDogMDtcclxuICAgIHBhZGRpbmc6IDc1JSAwO1xyXG4gICAgLyogcGFkZGluZyBjb250cm9scyBoZWlnaHQsIHdpbGwgYWx3YXlzIGJlIHBlcmZlY3RseSBzcXVhcmUgcmVnYXJkbGVzcyBvZiB3aWR0aCAqL1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgb3BhY2l0eTogMC44O1xyXG4gIH1cclxuICAuaW1nLXdyYXAgaW1ne1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gICAgbWluLWhlaWdodDogMTAwJTtcclxuICAgIG1heC13aWR0aDogMTUwJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgfSJdLCJzb3VyY2VSb290IjoiIn0= */

.aboutus-section {
    background: url(&quot;http://www.webcoderskull.com/img/right-sider-banner.png&quot;) no-repeat center top / cover;
    padding: 90px 0;
    margin:0;
}
.aboutus-title {
    font-size: 30px;
    letter-spacing: 0;
    line-height: 32px;
    margin: 0 0 39px;
    padding: 0 0 11px;
    position: relative;
    text-transform: uppercase;
    color: rgb(255, 255, 255);
}
.aboutus-title::after {
    background: #fdb801 none repeat scroll 0 0;
    bottom: 0;
    content: &quot;&quot;;
    height: 2px;
    left: 0;
    position: absolute;
    width: 54px;
}
.aboutus-text {
    color: #a8a3a3;
    font-size: 15px;
    line-height: 22px;
    margin: 0 0 35px;
}

a:hover, a:active {
    color: #ffb901;
    text-decoration: none;
    outline: 0;
}
.aboutus-more {
    border: 1px solid #fdb801;
    border-radius: 25px;
    color: #fdb801;
    display: inline-block;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0;
    padding: 7px 20px;
    text-transform: uppercase;
}
.feature .feature-box .iconset {
    background: rgb(69, 22, 97) none repeat scroll 0 0;
    float: left;
    position: relative;
    width: 18%;
}
.feature .feature-box .iconset::after {
    background: #fdb801 none repeat scroll 0 0;
    content: &quot;&quot;;
    height: 150%;
    left: 43%;
    position: absolute;
    top: 100%;
    width: 1px;
}

.feature .feature-box .feature-content h4 {
    color: #f8f8f8;
    font-size: 18px;
    letter-spacing: 0;
    line-height: 22px;
    margin: 0 0 5px;
}


.feature .feature-box .feature-content {
    float: left;
    padding-left: 28px;
    width: 78%;
}
.feature .feature-box .feature-content h4 {
    color: #fff0f0;
    font-size: 18px;
    letter-spacing: 0;
    line-height: 22px;
    margin: 0 0 5px;
}
.feature .feature-box .feature-content p {
    color: #a8a3a3;
    font-size: 15px;
    line-height: 22px;
}
.icon {
    color : #f4b841;
    padding:0px;
    font-size:40px;
    border: 1px solid #fdb801;
    border-radius: 100px;
    color: #fdb801;
    font-size: 28px;
    height: 70px;
    line-height: 70px;
    text-align: center;
    width: 70px;
}

.row.heading h2 {
    color: #fff;
    font-size: 52.52px;
    line-height: 95px;
    font-weight: 400;
    text-align: center;
    margin: 0 0 40px;
    padding-bottom: 20px;
    text-transform: uppercase;
}
ul{
  margin:0;
  padding:0;
  list-style:none;
}
.heading.heading-icon {
    display: block;
}
.padding-lg {
	display: block;
	padding-top: 60px;
	padding-bottom: 60px;
}
.practice-area.padding-lg {
    padding-bottom: 55px;
    padding-top: 55px;
}
.practice-area .inner{ 
     border:1px solid #999999; 
	 text-align:center; 
	 margin-bottom:28px; 
	 padding:40px 25px;
}
.our-webcoderskull .cnt-block:hover {
    box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.3);
    border: 0;
}
.practice-area .inner h3{ 
    color:#ffffff; 
	font-size:24px; 
	font-weight:500;
	font-family: 'Poppins', sans-serif;
	padding: 10px 0;
}
.practice-area .inner p{ 
    font-size:14px; 
	line-height:22px; 
	font-weight:400;
}
.practice-area .inner img{
	display:inline-block;
}

.our-webcoderskull .cnt-block{ 
   float:left; 
   width:100%; 
   background:#fff; 
   padding:30px 20px; 
   text-align:center; 
   border:2px solid #d5d5d5;
   margin: 0 0 28px;
}
.our-webcoderskull .cnt-block figure{
   width:148px; 
   height:148px; 
   border-radius:100%; 
   display:inline-block;
   margin-bottom: 15px;
}
.our-webcoderskull .cnt-block img{ 
   width:148px; 
   height:148px; 
   border-radius:100%; 
}
.GroupNames{
    color: #ffffff;
    text-align: center;
}

.row .heading .heading-icon{
    padding: 0;
    margin: 0;
}

/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvY3NzL0Fib3V0VXMuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUE7SUFDSSx1R0FBdUc7SUFDdkcsZUFBZTtJQUNmLFFBQVE7QUFDWjtBQUNBO0lBQ0ksZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsZ0JBQWdCO0lBQ2hCLGlCQUFpQjtJQUNqQixrQkFBa0I7SUFDbEIseUJBQXlCO0lBQ3pCLHlCQUF5QjtBQUM3QjtBQUNBO0lBQ0ksMENBQTBDO0lBQzFDLFNBQVM7SUFDVCxXQUFXO0lBQ1gsV0FBVztJQUNYLE9BQU87SUFDUCxrQkFBa0I7SUFDbEIsV0FBVztBQUNmO0FBQ0E7SUFDSSxjQUFjO0lBQ2QsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxjQUFjO0lBQ2QscUJBQXFCO0lBQ3JCLFVBQVU7QUFDZDtBQUNBO0lBQ0kseUJBQXlCO0lBQ3pCLG1CQUFtQjtJQUNuQixjQUFjO0lBQ2QscUJBQXFCO0lBQ3JCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQix5QkFBeUI7QUFDN0I7QUFDQTtJQUNJLGtEQUFrRDtJQUNsRCxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFVBQVU7QUFDZDtBQUNBO0lBQ0ksMENBQTBDO0lBQzFDLFdBQVc7SUFDWCxZQUFZO0lBQ1osU0FBUztJQUNULGtCQUFrQjtJQUNsQixTQUFTO0lBQ1QsVUFBVTtBQUNkOztBQUVBO0lBQ0ksY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkI7OztBQUdBO0lBQ0ksV0FBVztJQUNYLGtCQUFrQjtJQUNsQixVQUFVO0FBQ2Q7QUFDQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxjQUFjO0lBQ2QsZUFBZTtJQUNmLGlCQUFpQjtBQUNyQjtBQUNBO0lBQ0ksZUFBZTtJQUNmLFdBQVc7SUFDWCxjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLG9CQUFvQjtJQUNwQixjQUFjO0lBQ2QsZUFBZTtJQUNmLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLFdBQVc7QUFDZjs7QUFFQTtJQUNJLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQix5QkFBeUI7QUFDN0I7QUFDQTtFQUNFLFFBQVE7RUFDUixTQUFTO0VBQ1QsZUFBZTtBQUNqQjtBQUNBO0lBQ0ksY0FBYztBQUNsQjtBQUNBO0NBQ0MsY0FBYztDQUNkLGlCQUFpQjtDQUNqQixvQkFBb0I7QUFDckI7QUFDQTtJQUNJLG9CQUFvQjtJQUNwQixpQkFBaUI7QUFDckI7QUFDQTtLQUNLLHdCQUF3QjtFQUMzQixpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtBQUNuQjtBQUNBO0lBQ0ksaURBQWlEO0lBQ2pELFNBQVM7QUFDYjtBQUNBO0lBQ0ksYUFBYTtDQUNoQixjQUFjO0NBQ2QsZUFBZTtDQUNmLGtDQUFrQztDQUNsQyxlQUFlO0FBQ2hCO0FBQ0E7SUFDSSxjQUFjO0NBQ2pCLGdCQUFnQjtDQUNoQixlQUFlO0FBQ2hCO0FBQ0E7Q0FDQyxvQkFBb0I7QUFDckI7O0FBRUE7R0FDRyxVQUFVO0dBQ1YsVUFBVTtHQUNWLGVBQWU7R0FDZixpQkFBaUI7R0FDakIsaUJBQWlCO0dBQ2pCLHdCQUF3QjtHQUN4QixnQkFBZ0I7QUFDbkI7QUFDQTtHQUNHLFdBQVc7R0FDWCxZQUFZO0dBQ1osa0JBQWtCO0dBQ2xCLG9CQUFvQjtHQUNwQixtQkFBbUI7QUFDdEI7QUFDQTtHQUNHLFdBQVc7R0FDWCxZQUFZO0dBQ1osa0JBQWtCO0FBQ3JCO0FBQ0E7SUFDSSxjQUFjO0lBQ2Qsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksVUFBVTtJQUNWLFNBQVM7QUFDYiIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuLmFib3V0dXMtc2VjdGlvbiB7XHJcbiAgICBiYWNrZ3JvdW5kOiB1cmwoXCJodHRwOi8vd3d3LndlYmNvZGVyc2t1bGwuY29tL2ltZy9yaWdodC1zaWRlci1iYW5uZXIucG5nXCIpIG5vLXJlcGVhdCBjZW50ZXIgdG9wIC8gY292ZXI7XHJcbiAgICBwYWRkaW5nOiA5MHB4IDA7XHJcbiAgICBtYXJnaW46MDtcclxufVxyXG4uYWJvdXR1cy10aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMnB4O1xyXG4gICAgbWFyZ2luOiAwIDAgMzlweDtcclxuICAgIHBhZGRpbmc6IDAgMCAxMXB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XHJcbn1cclxuLmFib3V0dXMtdGl0bGU6OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQ6ICNmZGI4MDEgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBoZWlnaHQ6IDJweDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogNTRweDtcclxufVxyXG4uYWJvdXR1cy10ZXh0IHtcclxuICAgIGNvbG9yOiAjYThhM2EzO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBtYXJnaW46IDAgMCAzNXB4O1xyXG59XHJcblxyXG5hOmhvdmVyLCBhOmFjdGl2ZSB7XHJcbiAgICBjb2xvcjogI2ZmYjkwMTtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIG91dGxpbmU6IDA7XHJcbn1cclxuLmFib3V0dXMtbW9yZSB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmRiODAxO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICAgIGNvbG9yOiAjZmRiODAxO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgIGxldHRlci1zcGFjaW5nOiAwO1xyXG4gICAgcGFkZGluZzogN3B4IDIwcHg7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG59XHJcbi5mZWF0dXJlIC5mZWF0dXJlLWJveCAuaWNvbnNldCB7XHJcbiAgICBiYWNrZ3JvdW5kOiByZ2IoNjksIDIyLCA5Nykgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgd2lkdGg6IDE4JTtcclxufVxyXG4uZmVhdHVyZSAuZmVhdHVyZS1ib3ggLmljb25zZXQ6OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQ6ICNmZGI4MDEgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBoZWlnaHQ6IDE1MCU7XHJcbiAgICBsZWZ0OiA0MyU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwMCU7XHJcbiAgICB3aWR0aDogMXB4O1xyXG59XHJcblxyXG4uZmVhdHVyZSAuZmVhdHVyZS1ib3ggLmZlYXR1cmUtY29udGVudCBoNCB7XHJcbiAgICBjb2xvcjogI2Y4ZjhmODtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGxldHRlci1zcGFjaW5nOiAwO1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBtYXJnaW46IDAgMCA1cHg7XHJcbn1cclxuXHJcblxyXG4uZmVhdHVyZSAuZmVhdHVyZS1ib3ggLmZlYXR1cmUtY29udGVudCB7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIHBhZGRpbmctbGVmdDogMjhweDtcclxuICAgIHdpZHRoOiA3OCU7XHJcbn1cclxuLmZlYXR1cmUgLmZlYXR1cmUtYm94IC5mZWF0dXJlLWNvbnRlbnQgaDQge1xyXG4gICAgY29sb3I6ICNmZmYwZjA7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xyXG4gICAgbWFyZ2luOiAwIDAgNXB4O1xyXG59XHJcbi5mZWF0dXJlIC5mZWF0dXJlLWJveCAuZmVhdHVyZS1jb250ZW50IHAge1xyXG4gICAgY29sb3I6ICNhOGEzYTM7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjJweDtcclxufVxyXG4uaWNvbiB7XHJcbiAgICBjb2xvciA6ICNmNGI4NDE7XHJcbiAgICBwYWRkaW5nOjBweDtcclxuICAgIGZvbnQtc2l6ZTo0MHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZkYjgwMTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMHB4O1xyXG4gICAgY29sb3I6ICNmZGI4MDE7XHJcbiAgICBmb250LXNpemU6IDI4cHg7XHJcbiAgICBoZWlnaHQ6IDcwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogNzBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiA3MHB4O1xyXG59XHJcblxyXG4ucm93LmhlYWRpbmcgaDIge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBmb250LXNpemU6IDUyLjUycHg7XHJcbiAgICBsaW5lLWhlaWdodDogOTVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDAgMCA0MHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG59XHJcbnVse1xyXG4gIG1hcmdpbjowO1xyXG4gIHBhZGRpbmc6MDtcclxuICBsaXN0LXN0eWxlOm5vbmU7XHJcbn1cclxuLmhlYWRpbmcuaGVhZGluZy1pY29uIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcbi5wYWRkaW5nLWxnIHtcclxuXHRkaXNwbGF5OiBibG9jaztcclxuXHRwYWRkaW5nLXRvcDogNjBweDtcclxuXHRwYWRkaW5nLWJvdHRvbTogNjBweDtcclxufVxyXG4ucHJhY3RpY2UtYXJlYS5wYWRkaW5nLWxnIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1NXB4O1xyXG4gICAgcGFkZGluZy10b3A6IDU1cHg7XHJcbn1cclxuLnByYWN0aWNlLWFyZWEgLmlubmVyeyBcclxuICAgICBib3JkZXI6MXB4IHNvbGlkICM5OTk5OTk7IFxyXG5cdCB0ZXh0LWFsaWduOmNlbnRlcjsgXHJcblx0IG1hcmdpbi1ib3R0b206MjhweDsgXHJcblx0IHBhZGRpbmc6NDBweCAyNXB4O1xyXG59XHJcbi5vdXItd2ViY29kZXJza3VsbCAuY250LWJsb2NrOmhvdmVyIHtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMyk7XHJcbiAgICBib3JkZXI6IDA7XHJcbn1cclxuLnByYWN0aWNlLWFyZWEgLmlubmVyIGgzeyBcclxuICAgIGNvbG9yOiNmZmZmZmY7IFxyXG5cdGZvbnQtc2l6ZToyNHB4OyBcclxuXHRmb250LXdlaWdodDo1MDA7XHJcblx0Zm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuXHRwYWRkaW5nOiAxMHB4IDA7XHJcbn1cclxuLnByYWN0aWNlLWFyZWEgLmlubmVyIHB7IFxyXG4gICAgZm9udC1zaXplOjE0cHg7IFxyXG5cdGxpbmUtaGVpZ2h0OjIycHg7IFxyXG5cdGZvbnQtd2VpZ2h0OjQwMDtcclxufVxyXG4ucHJhY3RpY2UtYXJlYSAuaW5uZXIgaW1ne1xyXG5cdGRpc3BsYXk6aW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4ub3VyLXdlYmNvZGVyc2t1bGwgLmNudC1ibG9ja3sgXHJcbiAgIGZsb2F0OmxlZnQ7IFxyXG4gICB3aWR0aDoxMDAlOyBcclxuICAgYmFja2dyb3VuZDojZmZmOyBcclxuICAgcGFkZGluZzozMHB4IDIwcHg7IFxyXG4gICB0ZXh0LWFsaWduOmNlbnRlcjsgXHJcbiAgIGJvcmRlcjoycHggc29saWQgI2Q1ZDVkNTtcclxuICAgbWFyZ2luOiAwIDAgMjhweDtcclxufVxyXG4ub3VyLXdlYmNvZGVyc2t1bGwgLmNudC1ibG9jayBmaWd1cmV7XHJcbiAgIHdpZHRoOjE0OHB4OyBcclxuICAgaGVpZ2h0OjE0OHB4OyBcclxuICAgYm9yZGVyLXJhZGl1czoxMDAlOyBcclxuICAgZGlzcGxheTppbmxpbmUtYmxvY2s7XHJcbiAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuLm91ci13ZWJjb2RlcnNrdWxsIC5jbnQtYmxvY2sgaW1neyBcclxuICAgd2lkdGg6MTQ4cHg7IFxyXG4gICBoZWlnaHQ6MTQ4cHg7IFxyXG4gICBib3JkZXItcmFkaXVzOjEwMCU7IFxyXG59XHJcbi5Hcm91cE5hbWVze1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5yb3cgLmhlYWRpbmcgLmhlYWRpbmctaWNvbntcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */.treeStore {
    width: 100%;
    height: auto;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
  .treeStore .treeStoreName {
    font-family: cursive;
    font-size: 60px;
  }
  
  .treeList {
    width: 70vw;
    height: auto;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    place-items: center;
  }
  
  /* MENU ITEM STYLING */
  
  .tree {
    border-radius: 15px;
    width: 300px;
    height: 350px;
    margin: 20px;
    box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.2);
  }
  .tree:hover {
    box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.5);
    transition: 0.3s ease-in;
    cursor: pointer;
  }
  
  .tree div {
    border-top-left-radius: 15px;
    border-top-right-radius: 15px;
    width: 100%;
    height: 200px;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
  }
  
  .tree h1,
  .tree p {
    margin-left: 20px;
  }
  
  @media only screen and (max-width: 1300px) {
    .treeList {
      grid-template-columns: 1fr 1fr;
    }
  }
  
  @media only screen and (max-width: 800px) {
    .treeList {
      grid-template-columns: 1fr;
    }
  }
/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvVHJlZVN0b3JlLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsc0JBQXNCO0VBQ3hCO0VBQ0E7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osYUFBYTtJQUNiLGtDQUFrQztJQUNsQyxtQkFBbUI7RUFDckI7O0VBRUEsc0JBQXNCOztFQUV0QjtJQUNFLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osYUFBYTtJQUNiLFlBQVk7SUFDWiwyQ0FBMkM7RUFDN0M7RUFDQTtJQUNFLDJDQUEyQztJQUMzQyx3QkFBd0I7SUFDeEIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLDRCQUE0QjtJQUM1Qiw2QkFBNkI7SUFDN0IsV0FBVztJQUNYLGFBQWE7SUFDYiwyQkFBMkI7SUFDM0IsNEJBQTRCO0lBQzVCLHNCQUFzQjtFQUN4Qjs7RUFFQTs7SUFFRSxpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRTtNQUNFLDhCQUE4QjtJQUNoQztFQUNGOztFQUVBO0lBQ0U7TUFDRSwwQkFBMEI7SUFDNUI7RUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi50cmVlU3RvcmUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB9XHJcbiAgLnRyZWVTdG9yZSAudHJlZVN0b3JlTmFtZSB7XHJcbiAgICBmb250LWZhbWlseTogY3Vyc2l2ZTtcclxuICAgIGZvbnQtc2l6ZTogNjBweDtcclxuICB9XHJcbiAgXHJcbiAgLnRyZWVMaXN0IHtcclxuICAgIHdpZHRoOiA3MHZ3O1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDFmciAxZnI7XHJcbiAgICBwbGFjZS1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAvKiBNRU5VIElURU0gU1RZTElORyAqL1xyXG4gIFxyXG4gIC50cmVlIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbiAgICBoZWlnaHQ6IDM1MHB4O1xyXG4gICAgbWFyZ2luOiAyMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCAxNXB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICB9XHJcbiAgLnRyZWU6aG92ZXIge1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCAxNXB4IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIHRyYW5zaXRpb246IDAuM3MgZWFzZS1pbjtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbiAgXHJcbiAgLnRyZWUgZGl2IHtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDE1cHg7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gIH1cclxuICBcclxuICAudHJlZSBoMSxcclxuICAudHJlZSBwIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gIH1cclxuICBcclxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEzMDBweCkge1xyXG4gICAgLnRyZWVMaXN0IHtcclxuICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyO1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDgwMHB4KSB7XHJcbiAgICAudHJlZUxpc3Qge1xyXG4gICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmcjtcclxuICAgIH1cclxuICB9Il0sInNvdXJjZVJvb3QiOiIifQ== */.Account body{
    background: rgb(223, 210, 224);
    overflow: hidden;
}

.emp-profile{
    padding: 3%;
    margin-top: 3%;
    margin-bottom: 3%;
    border-radius: 0.5rem;
    border-style: solid;
     border-color: rgb(187, 143, 158);
   
}
.profile-img{
    text-align: center;
}
.profile-img img{
    width: 70%;
    height: 100%;
}
.profile-img .file {
    position: relative;
    overflow: hidden;
    margin-top: -20%;
    width: 70%;
    border: none;
    border-radius: 0;
    font-size: 15px;
    background: #212529b8;
}
.profile-img .file input {
    position: absolute;
    opacity: 0;
    right: 0;
    top: 0;
}
.profile-head h5{
    color: #333;
}
.profile-head h6{
    color: #0062cc;
}
.profile-edit-btn{
    border: none;
    border-radius: 1.5rem;
    width: 70%;
    padding: 2%;
    font-weight: 600;
    color: #6c757d;
    cursor: pointer;
}
.proile-rating{
    font-size: 12px;
    color: #818182;
    margin-top: 5%;
}
.proile-rating span{
    color: #495057;
    font-size: 15px;
    font-weight: 600;
}
.profile-head .nav-tabs{
    margin-bottom:5%;
}
.profile-head .nav-tabs .nav-link{
    font-weight:600;
    border: none;
}
.profile-head .nav-tabs .nav-link.active{
    border: none;
    border-bottom:2px solid #0062cc;
}
.profile-work{
    padding: 14%;
    margin-top: -15%;
}
.profile-work p{
    font-size: 12px;
    color: #818182;
    font-weight: 600;
    margin-top: 10%;
}
.profile-work a{
    text-decoration: none;
    color: #495057;
    font-weight: 600;
    font-size: 14px;
}
.profile-work ul{
    list-style: none;
}
.profile-tab label{
    font-weight: 600;
}
.profile-tab p{
    font-weight: 600;
    color: #0062cc;
}
.Acc {
    color: black;
}

body .bg-img{
    padding-top: 10%;
    padding-bottom: 10%;
}

 .submit-btn {
    display: inline-block;
    background-color: #000;
    background-image: linear-gradient(125deg,#a72879,#064497);
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 2px;
    font-size: 16px;
    padding: 8px 16px;
    border: none;
    width:200px;
    cursor: pointer;
  }
  .rowpad{
      margin-top: 4%;
  }
  .inp{
    margin-top: 5%;
    width: 70%;
    height: 60%;
  }
  .inp1{
    margin-top: 7%;
  }
  .lab{
    margin-top: 7%;
    margin-left: 13%;
    font-weight: bold;

  }
/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvQWNjb3VudC9Qcm9maWxlLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLDhCQUE4QjtJQUM5QixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLGlCQUFpQjtJQUNqQixxQkFBcUI7SUFDckIsbUJBQW1CO0tBQ2xCLGdDQUFnQzs7QUFFckM7QUFDQTtJQUNJLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0ksVUFBVTtJQUNWLFlBQVk7QUFDaEI7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLFVBQVU7SUFDVixZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGVBQWU7SUFDZixxQkFBcUI7QUFDekI7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsUUFBUTtJQUNSLE1BQU07QUFDVjtBQUNBO0lBQ0ksV0FBVztBQUNmO0FBQ0E7SUFDSSxjQUFjO0FBQ2xCO0FBQ0E7SUFDSSxZQUFZO0lBQ1oscUJBQXFCO0lBQ3JCLFVBQVU7SUFDVixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0FBQ25CO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsY0FBYztJQUNkLGNBQWM7QUFDbEI7QUFDQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSxnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLGVBQWU7SUFDZixZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxZQUFZO0lBQ1osK0JBQStCO0FBQ25DO0FBQ0E7SUFDSSxZQUFZO0lBQ1osZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsY0FBYztJQUNkLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxxQkFBcUI7SUFDckIsY0FBYztJQUNkLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGNBQWM7QUFDbEI7QUFDQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsbUJBQW1CO0FBQ3ZCOztDQUVDO0lBQ0cscUJBQXFCO0lBQ3JCLHNCQUFzQjtJQUN0Qix5REFBeUQ7SUFDekQsV0FBVztJQUNYLHlCQUF5QjtJQUN6QixtQkFBbUI7SUFDbkIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixZQUFZO0lBQ1osV0FBVztJQUNYLGVBQWU7RUFDakI7RUFDQTtNQUNJLGNBQWM7RUFDbEI7RUFDQTtJQUNFLGNBQWM7SUFDZCxVQUFVO0lBQ1YsV0FBVztFQUNiO0VBQ0E7SUFDRSxjQUFjO0VBQ2hCO0VBQ0E7SUFDRSxjQUFjO0lBQ2QsZ0JBQWdCO0lBQ2hCLGlCQUFpQjs7RUFFbkIiLCJzb3VyY2VzQ29udGVudCI6WyIuQWNjb3VudCBib2R5e1xyXG4gICAgYmFja2dyb3VuZDogcmdiKDIyMywgMjEwLCAyMjQpO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG5cclxuLmVtcC1wcm9maWxle1xyXG4gICAgcGFkZGluZzogMyU7XHJcbiAgICBtYXJnaW4tdG9wOiAzJTtcclxuICAgIG1hcmdpbi1ib3R0b206IDMlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMC41cmVtO1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgICBib3JkZXItY29sb3I6IHJnYigxODcsIDE0MywgMTU4KTtcclxuICAgXHJcbn1cclxuLnByb2ZpbGUtaW1ne1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5wcm9maWxlLWltZyBpbWd7XHJcbiAgICB3aWR0aDogNzAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcbi5wcm9maWxlLWltZyAuZmlsZSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgbWFyZ2luLXRvcDogLTIwJTtcclxuICAgIHdpZHRoOiA3MCU7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgYmFja2dyb3VuZDogIzIxMjUyOWI4O1xyXG59XHJcbi5wcm9maWxlLWltZyAuZmlsZSBpbnB1dCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbn1cclxuLnByb2ZpbGUtaGVhZCBoNXtcclxuICAgIGNvbG9yOiAjMzMzO1xyXG59XHJcbi5wcm9maWxlLWhlYWQgaDZ7XHJcbiAgICBjb2xvcjogIzAwNjJjYztcclxufVxyXG4ucHJvZmlsZS1lZGl0LWJ0bntcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEuNXJlbTtcclxuICAgIHdpZHRoOiA3MCU7XHJcbiAgICBwYWRkaW5nOiAyJTtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBjb2xvcjogIzZjNzU3ZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4ucHJvaWxlLXJhdGluZ3tcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjODE4MTgyO1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbn1cclxuLnByb2lsZS1yYXRpbmcgc3BhbntcclxuICAgIGNvbG9yOiAjNDk1MDU3O1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG4ucHJvZmlsZS1oZWFkIC5uYXYtdGFic3tcclxuICAgIG1hcmdpbi1ib3R0b206NSU7XHJcbn1cclxuLnByb2ZpbGUtaGVhZCAubmF2LXRhYnMgLm5hdi1saW5re1xyXG4gICAgZm9udC13ZWlnaHQ6NjAwO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG59XHJcbi5wcm9maWxlLWhlYWQgLm5hdi10YWJzIC5uYXYtbGluay5hY3RpdmV7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjMDA2MmNjO1xyXG59XHJcbi5wcm9maWxlLXdvcmt7XHJcbiAgICBwYWRkaW5nOiAxNCU7XHJcbiAgICBtYXJnaW4tdG9wOiAtMTUlO1xyXG59XHJcbi5wcm9maWxlLXdvcmsgcHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjODE4MTgyO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIG1hcmdpbi10b3A6IDEwJTtcclxufVxyXG4ucHJvZmlsZS13b3JrIGF7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBjb2xvcjogIzQ5NTA1NztcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuLnByb2ZpbGUtd29yayB1bHtcclxuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbn1cclxuLnByb2ZpbGUtdGFiIGxhYmVse1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG4ucHJvZmlsZS10YWIgcHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBjb2xvcjogIzAwNjJjYztcclxufVxyXG4uQWNjIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuYm9keSAuYmctaW1ne1xyXG4gICAgcGFkZGluZy10b3A6IDEwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMCU7XHJcbn1cclxuXHJcbiAuc3VibWl0LWJ0biB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KDEyNWRlZywjYTcyODc5LCMwNjQ0OTcpO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIHBhZGRpbmc6IDhweCAxNnB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgd2lkdGg6MjAwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgfVxyXG4gIC5yb3dwYWR7XHJcbiAgICAgIG1hcmdpbi10b3A6IDQlO1xyXG4gIH1cclxuICAuaW5we1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbiAgICB3aWR0aDogNzAlO1xyXG4gICAgaGVpZ2h0OiA2MCU7XHJcbiAgfVxyXG4gIC5pbnAxe1xyXG4gICAgbWFyZ2luLXRvcDogNyU7XHJcbiAgfVxyXG4gIC5sYWJ7XHJcbiAgICBtYXJnaW4tdG9wOiA3JTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMyU7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuXHJcbiAgfSJdLCJzb3VyY2VSb290IjoiIn0= */.body{
    display: flex;
    flex-direction: column;
    width: 1222px;
    margin: 0 auto;
    grid-gap: 50px;
    gap: 50px;
}

.flex-1-row{
    display: flex;
    flex-direction: row;
}

.flex-2-row{
    display: flex;
    flex-direction: row;
}
.button{
    border: solar;
    border-radius:1px;
    border-color: #AEABA6;
  color: black;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  background-color: #F4F1EA;
}

.flex1{
    display: flex;
    flex-direction: row-reverse;
}
.button1{
    border: solar;
    border-radius:1px;
    border-color: #AEABA6;
  color: black;
  padding: 8px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  background-color: #F4F1EA;
}
.title{
    /* position: absolute; */
font-family: Frank Ruhl Libre;
font-style: normal;
font-weight: bold;
font-size: 43px;
line-height: 56px;
}

.author{
    /* position: absolute; */
font-family: Frank Ruhl Libre;
font-style: normal;
font-weight: normal;
font-size: 24px;
line-height: 31px;
}

.genre{
    /* position: absolute; */

font-family: Frank Ruhl Libre;
font-style: normal;
font-weight: normal;
font-size: 20px;
line-height: 26px;
/* identical to box height */
}

.summary{
    /* position: absolute; */

font-family: Frank Ruhl Libre;
font-style: normal;
font-weight: normal;
font-size: 20px;
line-height: 26px;
}

.info{
    display: flex;
    flex-direction: column;
    padding-left: 31px;
}
.wherebuy{
    /* position: absolute; */

font-family: Arial;
font-style: normal;
font-weight: bold;
font-size: 19px;
line-height: 22px;
}

.Cover{
    /* position: absolute; */
    padding-top: 53px;
    width: 175px;
    height: 245px;
}

.topreiview{
    /* position: absolute; */

font-family: Arial;
font-style: normal;
font-weight: bold;
font-size: 19px;
line-height: 25px;
}
.padd{
    padding-bottom: 8px;
}
.row{
    flex-grow:1;
}

.avatar{
    width: 73px;
    height: 69px;
}

.namerate{
    width: 163px;
height: 20px;
    font-family: Arial;
font-style: normal;
font-weight: bold;
font-size: 17px;
line-height: 20px;
/* identical to box height */

display: flex;
align-items: center;
}

.comment{
    width: 1111px;
    height: 78px;
    font-family: Frank Ruhl Libre;
    font-style: normal;
    font-weight: normal;
    font-size: 20px;
    line-height: 26px;
}

.post__comment--list {
	padding: 0 16px;
}
/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcmMvYm9va3MuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksYUFBYTtJQUNiLHNCQUFzQjtJQUN0QixhQUFhO0lBQ2IsY0FBYztJQUNkLGNBQVM7SUFBVCxTQUFTO0FBQ2I7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksYUFBYTtJQUNiLG1CQUFtQjtBQUN2QjtBQUNBO0lBQ0ksYUFBYTtJQUNiLGlCQUFpQjtJQUNqQixxQkFBcUI7RUFDdkIsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIscUJBQXFCO0VBQ3JCLHFCQUFxQjtFQUNyQixlQUFlO0VBQ2YsZUFBZTtFQUNmLGVBQWU7RUFDZix5QkFBeUI7QUFDM0I7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsMkJBQTJCO0FBQy9CO0FBQ0E7SUFDSSxhQUFhO0lBQ2IsaUJBQWlCO0lBQ2pCLHFCQUFxQjtFQUN2QixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQixxQkFBcUI7RUFDckIscUJBQXFCO0VBQ3JCLGVBQWU7RUFDZixlQUFlO0VBQ2YsZUFBZTtFQUNmLHlCQUF5QjtBQUMzQjtBQUNBO0lBQ0ksd0JBQXdCO0FBQzVCLDZCQUE2QjtBQUM3QixrQkFBa0I7QUFDbEIsaUJBQWlCO0FBQ2pCLGVBQWU7QUFDZixpQkFBaUI7QUFDakI7O0FBRUE7SUFDSSx3QkFBd0I7QUFDNUIsNkJBQTZCO0FBQzdCLGtCQUFrQjtBQUNsQixtQkFBbUI7QUFDbkIsZUFBZTtBQUNmLGlCQUFpQjtBQUNqQjs7QUFFQTtJQUNJLHdCQUF3Qjs7QUFFNUIsNkJBQTZCO0FBQzdCLGtCQUFrQjtBQUNsQixtQkFBbUI7QUFDbkIsZUFBZTtBQUNmLGlCQUFpQjtBQUNqQiw0QkFBNEI7QUFDNUI7O0FBRUE7SUFDSSx3QkFBd0I7O0FBRTVCLDZCQUE2QjtBQUM3QixrQkFBa0I7QUFDbEIsbUJBQW1CO0FBQ25CLGVBQWU7QUFDZixpQkFBaUI7QUFDakI7O0FBRUE7SUFDSSxhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0ksd0JBQXdCOztBQUU1QixrQkFBa0I7QUFDbEIsa0JBQWtCO0FBQ2xCLGlCQUFpQjtBQUNqQixlQUFlO0FBQ2YsaUJBQWlCO0FBQ2pCOztBQUVBO0lBQ0ksd0JBQXdCO0lBQ3hCLGlCQUFpQjtJQUNqQixZQUFZO0lBQ1osYUFBYTtBQUNqQjs7QUFFQTtJQUNJLHdCQUF3Qjs7QUFFNUIsa0JBQWtCO0FBQ2xCLGtCQUFrQjtBQUNsQixpQkFBaUI7QUFDakIsZUFBZTtBQUNmLGlCQUFpQjtBQUNqQjtBQUNBO0lBQ0ksbUJBQW1CO0FBQ3ZCO0FBQ0E7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLFlBQVk7QUFDaEIsWUFBWTtJQUNSLGtCQUFrQjtBQUN0QixrQkFBa0I7QUFDbEIsaUJBQWlCO0FBQ2pCLGVBQWU7QUFDZixpQkFBaUI7QUFDakIsNEJBQTRCOztBQUU1QixhQUFhO0FBQ2IsbUJBQW1CO0FBQ25COztBQUVBO0lBQ0ksYUFBYTtJQUNiLFlBQVk7SUFDWiw2QkFBNkI7SUFDN0Isa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQixlQUFlO0lBQ2YsaUJBQWlCO0FBQ3JCOztBQUVBO0NBQ0MsZUFBZTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5ib2R5e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICB3aWR0aDogMTIyMnB4O1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICBnYXA6IDUwcHg7XHJcbn1cclxuXHJcbi5mbGV4LTEtcm93e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbn1cclxuXHJcbi5mbGV4LTItcm93e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbn1cclxuLmJ1dHRvbntcclxuICAgIGJvcmRlcjogc29sYXI7XHJcbiAgICBib3JkZXItcmFkaXVzOjFweDtcclxuICAgIGJvcmRlci1jb2xvcjogI0FFQUJBNjtcclxuICBjb2xvcjogYmxhY2s7XHJcbiAgcGFkZGluZzogMTJweCAzMnB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBtYXJnaW46IDRweCAycHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGNEYxRUE7XHJcbn1cclxuXHJcbi5mbGV4MXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93LXJldmVyc2U7XHJcbn1cclxuLmJ1dHRvbjF7XHJcbiAgICBib3JkZXI6IHNvbGFyO1xyXG4gICAgYm9yZGVyLXJhZGl1czoxcHg7XHJcbiAgICBib3JkZXItY29sb3I6ICNBRUFCQTY7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIHBhZGRpbmc6IDhweCAzMnB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBtYXJnaW46IDRweCAycHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGNEYxRUE7XHJcbn1cclxuLnRpdGxle1xyXG4gICAgLyogcG9zaXRpb246IGFic29sdXRlOyAqL1xyXG5mb250LWZhbWlseTogRnJhbmsgUnVobCBMaWJyZTtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogYm9sZDtcclxuZm9udC1zaXplOiA0M3B4O1xyXG5saW5lLWhlaWdodDogNTZweDtcclxufVxyXG5cclxuLmF1dGhvcntcclxuICAgIC8qIHBvc2l0aW9uOiBhYnNvbHV0ZTsgKi9cclxuZm9udC1mYW1pbHk6IEZyYW5rIFJ1aGwgTGlicmU7XHJcbmZvbnQtc3R5bGU6IG5vcm1hbDtcclxuZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuZm9udC1zaXplOiAyNHB4O1xyXG5saW5lLWhlaWdodDogMzFweDtcclxufVxyXG5cclxuLmdlbnJle1xyXG4gICAgLyogcG9zaXRpb246IGFic29sdXRlOyAqL1xyXG5cclxuZm9udC1mYW1pbHk6IEZyYW5rIFJ1aGwgTGlicmU7XHJcbmZvbnQtc3R5bGU6IG5vcm1hbDtcclxuZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuZm9udC1zaXplOiAyMHB4O1xyXG5saW5lLWhlaWdodDogMjZweDtcclxuLyogaWRlbnRpY2FsIHRvIGJveCBoZWlnaHQgKi9cclxufVxyXG5cclxuLnN1bW1hcnl7XHJcbiAgICAvKiBwb3NpdGlvbjogYWJzb2x1dGU7ICovXHJcblxyXG5mb250LWZhbWlseTogRnJhbmsgUnVobCBMaWJyZTtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogbm9ybWFsO1xyXG5mb250LXNpemU6IDIwcHg7XHJcbmxpbmUtaGVpZ2h0OiAyNnB4O1xyXG59XHJcblxyXG4uaW5mb3tcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAzMXB4O1xyXG59XHJcbi53aGVyZWJ1eXtcclxuICAgIC8qIHBvc2l0aW9uOiBhYnNvbHV0ZTsgKi9cclxuXHJcbmZvbnQtZmFtaWx5OiBBcmlhbDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogYm9sZDtcclxuZm9udC1zaXplOiAxOXB4O1xyXG5saW5lLWhlaWdodDogMjJweDtcclxufVxyXG5cclxuLkNvdmVye1xyXG4gICAgLyogcG9zaXRpb246IGFic29sdXRlOyAqL1xyXG4gICAgcGFkZGluZy10b3A6IDUzcHg7XHJcbiAgICB3aWR0aDogMTc1cHg7XHJcbiAgICBoZWlnaHQ6IDI0NXB4O1xyXG59XHJcblxyXG4udG9wcmVpdmlld3tcclxuICAgIC8qIHBvc2l0aW9uOiBhYnNvbHV0ZTsgKi9cclxuXHJcbmZvbnQtZmFtaWx5OiBBcmlhbDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogYm9sZDtcclxuZm9udC1zaXplOiAxOXB4O1xyXG5saW5lLWhlaWdodDogMjVweDtcclxufVxyXG4ucGFkZHtcclxuICAgIHBhZGRpbmctYm90dG9tOiA4cHg7XHJcbn1cclxuLnJvd3tcclxuICAgIGZsZXgtZ3JvdzoxO1xyXG59XHJcblxyXG4uYXZhdGFye1xyXG4gICAgd2lkdGg6IDczcHg7XHJcbiAgICBoZWlnaHQ6IDY5cHg7XHJcbn1cclxuXHJcbi5uYW1lcmF0ZXtcclxuICAgIHdpZHRoOiAxNjNweDtcclxuaGVpZ2h0OiAyMHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IEFyaWFsO1xyXG5mb250LXN0eWxlOiBub3JtYWw7XHJcbmZvbnQtd2VpZ2h0OiBib2xkO1xyXG5mb250LXNpemU6IDE3cHg7XHJcbmxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4vKiBpZGVudGljYWwgdG8gYm94IGhlaWdodCAqL1xyXG5cclxuZGlzcGxheTogZmxleDtcclxuYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmNvbW1lbnR7XHJcbiAgICB3aWR0aDogMTExMXB4O1xyXG4gICAgaGVpZ2h0OiA3OHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IEZyYW5rIFJ1aGwgTGlicmU7XHJcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XHJcbn1cclxuXHJcbi5wb3N0X19jb21tZW50LS1saXN0IHtcclxuXHRwYWRkaW5nOiAwIDE2cHg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}
  
    What are you reading?search 
    
    

  

/html[1]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
   </webElementXpaths>
</WebElementEntity>
