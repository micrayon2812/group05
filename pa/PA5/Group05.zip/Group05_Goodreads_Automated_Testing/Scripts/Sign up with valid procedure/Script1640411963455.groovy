import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.goodreads.com/')

WebUI.click(findTestObject('Object Repository/Page_Goodreads  Meet your next favorite book/a_Sign up with email'))

WebUI.setText(findTestObject('Object Repository/Page_Sign Up/input_Name_userfirst_name'), 'Ngan')

WebUI.setText(findTestObject('Object Repository/Page_Sign Up/input_Email address_useremail'), 'kadamei.kun@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Sign Up/input_Password_userpassword'), 'rhDY9kG0HhLhYiiSeXT5qQ==')

WebUI.click(findTestObject('Object Repository/Page_Sign Up/div_id(katalon-rec_elementInfoDiv) (1)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/img_Click verify once there are none left_rc-image-tile-33'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/img_Click verify once there are none left_rc-image-tile-33'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/img_Click verify once there are none left_rc-image-tile-33'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/button_Verify (3)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/div_Click verify once there are none left_r_f144f7'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/button_Verify (3)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/img_traffic lights_rc-image-tile-44 (1)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/img_traffic lights_rc-image-tile-44 (1)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/img_traffic lights_rc-image-tile-44 (1)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/button_Verify (3)'))

WebUI.click(findTestObject('Object Repository/Page_Sign Up/input_Password_next'))

WebUI.click(findTestObject('Object Repository/Page_Set a Reading Goal  Goodreads/a_skip this step'))

WebUI.click(findTestObject('Object Repository/Page_Select Your Favorite Genres  Goodreads/input_Manga_favoritesManga'))

WebUI.click(findTestObject('Object Repository/Page_Select Your Favorite Genres  Goodreads/input_Ebooks_favoritesEbooks'))

WebUI.click(findTestObject('Object Repository/Page_Select Your Favorite Genres  Goodreads/input_Fantasy_favoritesFantasy'))

WebUI.click(findTestObject('Object Repository/Page_Select Your Favorite Genres  Goodreads/input_Enter other favorite genres, separate_df9327'))

WebUI.click(findTestObject('Object Repository/Page_Registration Rate Books  Goodreads/a_5 of 5 stars'))

WebUI.click(findTestObject('Object Repository/Page_Registration Rate Books  Goodreads/a_Im finished rating'))

WebUI.click(findTestObject('Object Repository/Page_Recommended for You  Goodreads/div_Done here See whats next'))

WebUI.click(findTestObject('Object Repository/Page_Recommended for You  Goodreads/div_Done here See whats next'))

WebUI.click(findTestObject('Object Repository/Page_Recent updates  Goodreads/h5_Welcome to Goodreads'))

